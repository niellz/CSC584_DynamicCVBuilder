<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Dynamic CV Builder - Enter Your Details</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

<div class="page-header">
    <h1>Dynamic Online CV Builder</h1>
    <p>Fill in your details and generate a printable CV instantly</p>
</div>

<div class="container">

    <!-- GET flow: sample template -->
    <div class="card">
        <strong>Want to see how it looks first?</strong>
        <p style="margin:6px 0 12px">Generate a ready-made template filled with sample data.</p>
        <a class="btn btn-accent" href="CVServlet?action=sample">Preview Sample CV</a>
    </div>

    <!-- POST flow: user data -->
    <form action="CVServlet" method="post" accept-charset="UTF-8">

        <div class="card">
            <h2>Personal Information</h2>
            <div class="form-row">
                <div class="form-group">
                    <label for="fullName">Full Name <span class="req">*</span></label>
                    <input type="text" id="fullName" name="fullName" placeholder="e.g. Abu bin Ali" required>
                </div>
                <div class="form-group">
                    <label for="professionalTitle">Professional Title</label>
                    <input type="text" id="professionalTitle" name="professionalTitle" placeholder="e.g. Java Developer">
                </div>
                <div class="form-group">
                    <label for="email">Email <span class="req">*</span></label>
                    <input type="email" id="email" name="email" placeholder="name@example.com" required>
                </div>
                <div class="form-group">
                    <label for="phone">Phone Number</label>
                    <input type="tel" id="phone" name="phone" placeholder="+60 12-345 6789">
                </div>
                <div class="form-group full">
                    <label for="profileUrl">LinkedIn / GitHub URL</label>
                    <input type="url" id="profileUrl" name="profileUrl" placeholder="https://github.com/username">
                </div>
                <div class="form-group full">
                    <label for="profileSummary">Profile Summary</label>
                    <textarea id="profileSummary" name="profileSummary" rows="4"
                              placeholder="A short paragraph about you and your career goals"></textarea>
                </div>
            </div>
        </div>

        <div class="card">
            <h2>Education</h2>
            <div class="form-row">
                <div class="form-group">
                    <label for="degree">Highest Degree <span class="req">*</span></label>
                    <input type="text" id="degree" name="degree" placeholder="e.g. Bachelor of Computer Science" required>
                </div>
                <div class="form-group">
                    <label for="major">Major / Field</label>
                    <input type="text" id="major" name="major" placeholder="e.g. Computer Science">
                </div>
                <div class="form-group">
                    <label for="institution">Institution Name</label>
                    <input type="text" id="institution" name="institution" placeholder="e.g. UiTM Cawangan Terengganu">
                </div>
                <div class="form-group">
                    <label for="graduationYear">Year of Graduation</label>
                    <input type="text" id="graduationYear" name="graduationYear" placeholder="e.g. 2026" maxlength="4">
                </div>
            </div>
        </div>

        <div class="card">
            <h2>Experience</h2>
            <div class="form-row">
                <div class="form-group">
                    <label for="jobTitle">Most Recent Job Title</label>
                    <input type="text" id="jobTitle" name="jobTitle" placeholder="e.g. Software Developer Intern">
                </div>
                <div class="form-group">
                    <label for="company">Company Name</label>
                    <input type="text" id="company" name="company" placeholder="e.g. ABC Sdn. Bhd.">
                </div>
                <div class="form-group full">
                    <label for="duration">Duration</label>
                    <input type="text" id="duration" name="duration" placeholder="e.g. March 2025 - August 2025">
                </div>
                <div class="form-group full">
                    <label for="responsibilities">Key Responsibilities / Achievements</label>
                    <textarea id="responsibilities" name="responsibilities" rows="5"
                              placeholder="One item per line"></textarea>
                    <span class="hint">Write one responsibility or achievement per line.</span>
                </div>
            </div>
        </div>

        <div class="card">
            <h2>Skills</h2>
            <div class="form-group">
                <label for="technicalSkills">Technical Skills <span class="req">*</span></label>
                <input type="text" id="technicalSkills" name="technicalSkills" placeholder="Java, JSP, MySQL, Git">
                <span class="hint">Separate skills with commas. At least one skill is required.</span>
            </div>
            <div class="form-group">
                <label for="softSkills">Soft Skills</label>
                <input type="text" id="softSkills" name="softSkills" placeholder="Teamwork, Communication">
                <span class="hint">Separate skills with commas.</span>
            </div>
        </div>

        <div class="actions">
            <button type="submit" class="btn btn-primary">Generate My CV</button>
            <button type="reset" class="btn btn-secondary">Clear Form</button>
        </div>
    </form>
</div>

</body>
</html>
