<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib uri="jakarta.tags.core" prefix="c" %>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Validation Error - CV Builder</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

<div class="page-header">
    <h1>Dynamic Online CV Builder</h1>
    <p>Something needs your attention</p>
</div>

<div class="container">
    <div class="error-box">
        <h2>Validation Error</h2>
        <p><c:out value="${errorMessage}" default="Invalid input."/></p>
        <ul>
            <c:forEach var="err" items="${errors}">
                <li><c:out value="${err}"/></li>
            </c:forEach>
        </ul>
    </div>

    <div class="actions">
        <!-- history.back() keeps what the user already typed -->
        <button type="button" class="btn btn-primary" onclick="history.back()">&larr; Go Back &amp; Correct</button>
        <a class="btn btn-secondary" href="cvForm.jsp">Start With a Blank Form</a>
    </div>
</div>

</body>
</html>
