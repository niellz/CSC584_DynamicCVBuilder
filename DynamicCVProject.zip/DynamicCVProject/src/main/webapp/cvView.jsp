<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib uri="jakarta.tags.core" prefix="c" %>
<%-- VIEW: presentation only. Data comes from the CVBean stored in request scope by CVServlet. --%>
<c:if test="${empty cvData}">
    <c:redirect url="cvForm.jsp"/>
</c:if>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>CV - <c:out value="${cvData.fullName}"/></title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&amp;family=Playfair+Display:wght@700;800&amp;display=swap">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
<div class="container">

    <c:if test="${isSample}">
        <div class="sample-banner no-print">This is a <strong>sample CV</strong> generated with dummy data.</div>
    </c:if>

    <div class="toolbar no-print">
        <a class="btn btn-secondary" href="cvForm.jsp">&larr; Back to Form</a>
        <button type="button" class="btn btn-primary" onclick="window.print()">Print / Save as PDF</button>
    </div>

    <div class="cv-sheet">

        <!-- ================= Sidebar ================= -->
        <div class="cv-side">
            <svg class="profile-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round" aria-label="Profile" role="img">
                <circle cx="12" cy="8" r="4.2"/>
                <path d="M3.8 21c.6-4.4 4-6.8 8.2-6.8s7.6 2.4 8.2 6.8"/>
            </svg>

            <div class="side-sec">
                <h2>Contact</h2>
                <div class="c-label">Email</div>
                <div class="c-value"><c:out value="${cvData.email}"/></div>
                <c:if test="${not empty cvData.phone}">
                    <div class="c-label">Phone</div>
                    <div class="c-value"><c:out value="${cvData.phone}"/></div>
                </c:if>
                <c:if test="${not empty cvData.profileUrl}">
                    <div class="c-label">Profile</div>
                    <div class="c-value"><a href="<c:out value='${cvData.profileUrl}'/>" target="_blank"><c:out value="${cvData.profileUrl}"/></a></div>
                </c:if>
            </div>

            <c:if test="${not empty cvData.technicalSkillList}">
                <div class="side-sec">
                    <h2>Technical Skills</h2>
                    <div class="pills">
                        <c:forEach var="s" items="${cvData.technicalSkillList}">
                            <span class="pill"><c:out value="${s}"/></span>
                        </c:forEach>
                    </div>
                </div>
            </c:if>

            <c:if test="${not empty cvData.softSkillList}">
                <div class="side-sec">
                    <h2>Soft Skills</h2>
                    <ul class="dot-list">
                        <c:forEach var="s" items="${cvData.softSkillList}">
                            <li><c:out value="${s}"/></li>
                        </c:forEach>
                    </ul>
                </div>
            </c:if>
        </div>

        <!-- ================= Main ================= -->
        <div class="cv-main">
            <h1><c:out value="${cvData.fullName}"/></h1>
            <c:if test="${not empty cvData.professionalTitle}">
                <div class="role"><c:out value="${cvData.professionalTitle}"/></div>
            </c:if>

            <c:if test="${not empty cvData.profileSummary}">
                <div class="main-sec">
                    <h2>Profile</h2>
                    <p><c:out value="${cvData.profileSummary}"/></p>
                </div>
            </c:if>

            <c:if test="${cvData.hasExperience}">
                <div class="main-sec">
                    <h2>Experience</h2>
                    <div class="entry-head">
                        <span class="entry-title"><c:out value="${cvData.jobTitle}"/></span>
                        <c:if test="${not empty cvData.duration}">
                            <span class="entry-date"><c:out value="${cvData.duration}"/></span>
                        </c:if>
                    </div>
                    <c:if test="${not empty cvData.company}">
                        <div class="entry-org"><c:out value="${cvData.company}"/></div>
                    </c:if>
                    <c:if test="${not empty cvData.responsibilityList}">
                        <ul class="dash-list">
                            <c:forEach var="item" items="${cvData.responsibilityList}">
                                <li><c:out value="${item}"/></li>
                            </c:forEach>
                        </ul>
                    </c:if>
                </div>
            </c:if>

            <div class="main-sec">
                <h2>Education</h2>
                <div class="entry-title"><c:out value="${cvData.degree}"/></div>
                <c:if test="${not empty cvData.major}">
                    <div class="entry-line"><c:out value="${cvData.major}"/></div>
                </c:if>
                <c:if test="${not empty cvData.institution or not empty cvData.graduationYear}">
                    <div class="entry-org">
                        <c:out value="${cvData.institution}"/><c:if test="${not empty cvData.institution and not empty cvData.graduationYear}"> &middot; </c:if><c:out value="${cvData.graduationYear}"/>
                    </div>
                </c:if>
            </div>
        </div>

    </div>
</div>
</body>
</html>
