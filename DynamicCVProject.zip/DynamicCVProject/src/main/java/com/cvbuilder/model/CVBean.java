package com.cvbuilder.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

/**
 * MODEL layer (MVC).
 * JavaBean that encapsulates all candidate data for the CV and holds the
 * validation rules. It has private fields, a zero-argument constructor and
 * public getters/setters, as required by the JavaBean specification.
 */
public class CVBean implements Serializable {

    private static final long serialVersionUID = 1L;

    private static final Pattern EMAIL_PATTERN =
            Pattern.compile("^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$");
    private static final Pattern PHONE_PATTERN =
            Pattern.compile("^[+]?[0-9\\s\\-()]{7,20}$");
    private static final Pattern YEAR_PATTERN =
            Pattern.compile("^(19|20)\\d{2}$");

    // ---------- Personal Info ----------
    private String fullName;
    private String professionalTitle;
    private String email;
    private String phone;
    private String profileUrl;      // LinkedIn / GitHub
    private String profileSummary;

    // ---------- Education ----------
    private String degree;
    private String institution;
    private String graduationYear;
    private String major;

    // ---------- Experience ----------
    private String jobTitle;
    private String company;
    private String duration;
    private String responsibilities;

    // ---------- Skills ----------
    private String technicalSkills; // comma-separated
    private String softSkills;      // comma-separated

    // ---------- Validation result ----------
    private List<String> errors = new ArrayList<String>();

    /** Zero-argument constructor (JavaBean requirement). */
    public CVBean() {
    }

    // =====================================================
    //  Validation logic
    // =====================================================

    /**
     * Validates the mandatory fields: Name, Email, Degree and at least one
     * Skill. Email, phone and graduation year are also checked for format
     * when supplied. Messages are collected in {@link #getErrors()}.
     *
     * @return true if the data is valid, false otherwise
     */
    public boolean validate() {
        errors.clear();

        if (isBlank(fullName)) {
            errors.add("Full Name is required.");
        } else if (fullName.trim().length() < 3) {
            errors.add("Full Name must be at least 3 characters long.");
        }

        if (isBlank(email)) {
            errors.add("Email is required.");
        } else if (!EMAIL_PATTERN.matcher(email.trim()).matches()) {
            errors.add("Email format is invalid (example: name@example.com).");
        }

        if (isBlank(degree)) {
            errors.add("Highest Degree is required.");
        }

        if (getTechnicalSkillList().isEmpty() && getSoftSkillList().isEmpty()) {
            errors.add("At least one skill (technical or soft) is required.");
        }

        if (!isBlank(phone) && !PHONE_PATTERN.matcher(phone.trim()).matches()) {
            errors.add("Phone Number format is invalid (digits, spaces, +, -, brackets only).");
        }

        if (!isBlank(graduationYear) && !YEAR_PATTERN.matcher(graduationYear.trim()).matches()) {
            errors.add("Year of Graduation must be a valid 4-digit year (e.g. 2026).");
        }

        return errors.isEmpty();
    }

    private static boolean isBlank(String s) {
        return s == null || s.trim().isEmpty();
    }

    private static List<String> split(String raw, String regex) {
        List<String> list = new ArrayList<String>();
        if (raw == null) {
            return list;
        }
        for (String part : raw.split(regex)) {
            String t = part.trim();
            if (!t.isEmpty()) {
                list.add(t);
            }
        }
        return list;
    }

    // =====================================================
    //  Derived (read-only) properties used by the View
    // =====================================================

    public List<String> getTechnicalSkillList() {
        return split(technicalSkills, ",");
    }

    public List<String> getSoftSkillList() {
        return split(softSkills, ",");
    }

    /** One responsibility per line. */
    public List<String> getResponsibilityList() {
        return split(responsibilities, "\\r?\\n");
    }

    public boolean isHasExperience() {
        return !isBlank(jobTitle) || !isBlank(company);
    }

    public List<String> getErrors() {
        return errors;
    }

    // =====================================================
    //  Getters and setters
    // =====================================================

    public String getFullName() { return fullName; }
    public void setFullName(String fullName) { this.fullName = trim(fullName); }

    public String getProfessionalTitle() { return professionalTitle; }
    public void setProfessionalTitle(String professionalTitle) { this.professionalTitle = trim(professionalTitle); }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = trim(email); }

    public String getPhone() { return phone; }
    public void setPhone(String phone) { this.phone = trim(phone); }

    public String getProfileUrl() { return profileUrl; }
    public void setProfileUrl(String profileUrl) { this.profileUrl = trim(profileUrl); }

    public String getProfileSummary() { return profileSummary; }
    public void setProfileSummary(String profileSummary) { this.profileSummary = trim(profileSummary); }

    public String getDegree() { return degree; }
    public void setDegree(String degree) { this.degree = trim(degree); }

    public String getInstitution() { return institution; }
    public void setInstitution(String institution) { this.institution = trim(institution); }

    public String getGraduationYear() { return graduationYear; }
    public void setGraduationYear(String graduationYear) { this.graduationYear = trim(graduationYear); }

    public String getMajor() { return major; }
    public void setMajor(String major) { this.major = trim(major); }

    public String getJobTitle() { return jobTitle; }
    public void setJobTitle(String jobTitle) { this.jobTitle = trim(jobTitle); }

    public String getCompany() { return company; }
    public void setCompany(String company) { this.company = trim(company); }

    public String getDuration() { return duration; }
    public void setDuration(String duration) { this.duration = trim(duration); }

    public String getResponsibilities() { return responsibilities; }
    public void setResponsibilities(String responsibilities) { this.responsibilities = trim(responsibilities); }

    public String getTechnicalSkills() { return technicalSkills; }
    public void setTechnicalSkills(String technicalSkills) { this.technicalSkills = trim(technicalSkills); }

    public String getSoftSkills() { return softSkills; }
    public void setSoftSkills(String softSkills) { this.softSkills = trim(softSkills); }

    private static String trim(String s) {
        return s == null ? null : s.trim();
    }
}
