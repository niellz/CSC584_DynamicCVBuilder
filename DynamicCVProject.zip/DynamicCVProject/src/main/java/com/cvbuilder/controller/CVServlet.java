package com.cvbuilder.controller;

import com.cvbuilder.model.CVBean;

import java.io.IOException;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

/**
 * CONTROLLER layer (MVC).
 *
 * POST  /CVServlet               : process the submitted form, validate, forward to the view.
 * GET   /CVServlet?action=sample : build a pre-populated sample CV and forward to the view.
 * GET   /CVServlet               : forward to the input form.
 */
public class CVServlet extends HttpServlet {

    private static final long serialVersionUID = 1L;

    private static final String FORM_VIEW  = "/cvForm.jsp";
    private static final String CV_VIEW    = "/cvView.jsp";
    private static final String ERROR_VIEW = "/cvError.jsp";

    // ------------------------------------------------------------------
    //  GET : sample template generation (no user input)
    // ------------------------------------------------------------------
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String action = request.getParameter("action");

        if ("sample".equals(action)) {
            CVBean sample = createSampleBean();
            request.setAttribute("cvData", sample);
            request.setAttribute("isSample", Boolean.TRUE);
            forward(request, response, CV_VIEW);
        } else {
            forward(request, response, FORM_VIEW);
        }
    }

    // ------------------------------------------------------------------
    //  POST : handle form submission
    // ------------------------------------------------------------------
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        request.setCharacterEncoding("UTF-8");

        // 1. Read form data and populate the model bean
        CVBean cvBean = new CVBean();
        cvBean.setFullName(request.getParameter("fullName"));
        cvBean.setProfessionalTitle(request.getParameter("professionalTitle"));
        cvBean.setEmail(request.getParameter("email"));
        cvBean.setPhone(request.getParameter("phone"));
        cvBean.setProfileUrl(request.getParameter("profileUrl"));
        cvBean.setProfileSummary(request.getParameter("profileSummary"));

        cvBean.setDegree(request.getParameter("degree"));
        cvBean.setInstitution(request.getParameter("institution"));
        cvBean.setGraduationYear(request.getParameter("graduationYear"));
        cvBean.setMajor(request.getParameter("major"));

        cvBean.setJobTitle(request.getParameter("jobTitle"));
        cvBean.setCompany(request.getParameter("company"));
        cvBean.setDuration(request.getParameter("duration"));
        cvBean.setResponsibilities(request.getParameter("responsibilities"));

        cvBean.setTechnicalSkills(request.getParameter("technicalSkills"));
        cvBean.setSoftSkills(request.getParameter("softSkills"));

        // 2. Validate through the bean
        if (cvBean.validate()) {
            request.setAttribute("cvData", cvBean);
            request.setAttribute("isSample", Boolean.FALSE);
            forward(request, response, CV_VIEW);
        } else {
            request.setAttribute("errors", cvBean.getErrors());
            request.setAttribute("errorMessage",
                    "Your CV could not be generated. Please correct the following problem(s):");
            forward(request, response, ERROR_VIEW);
        }
    }

    // ------------------------------------------------------------------
    //  Helpers
    // ------------------------------------------------------------------
    private void forward(HttpServletRequest request, HttpServletResponse response, String view)
            throws ServletException, IOException {
        RequestDispatcher dispatcher = request.getRequestDispatcher(view);
        dispatcher.forward(request, response);
    }

    /** Builds a CVBean filled with realistic dummy data using its setters. */
    private CVBean createSampleBean() {
        CVBean b = new CVBean();

        b.setFullName("Amir bin Kamarulzaman");
        b.setProfessionalTitle("Junior Full-Stack Java Developer");
        b.setEmail("amir@example.com");
        b.setPhone("+60 12-345 6789");
        b.setProfileUrl("https://www.linkedin.com/in/amir-demo");
        b.setProfileSummary("Detail-oriented computer science graduate with hands-on experience "
                + "building Java EE web applications using the MVC pattern. Passionate about clean "
                + "code, secure web development and continuous learning. Seeking a junior developer "
                + "role to contribute to enterprise software projects.");

        b.setDegree("Bachelor of Computer Science (Hons.)");
        b.setInstitution("Universiti Teknologi MARA (UiTM) Cawangan Terengganu");
        b.setGraduationYear("2026");
        b.setMajor("Computer Science");

        b.setJobTitle("Software Developer Intern");
        b.setCompany("Nusantara Tech Solutions Sdn. Bhd.");
        b.setDuration("March 2025 - August 2025");
        b.setResponsibilities(
                "Developed and maintained internal web modules using Servlets, JSP and MySQL.\n"
              + "Reduced report generation time by 40% by optimising SQL queries.\n"
              + "Wrote unit tests with JUnit and fixed 25+ reported defects.\n"
              + "Collaborated with a team of 6 in Agile sprints using Git and Jira.");

        b.setTechnicalSkills("Java, JSP & Servlets, JavaBeans, MySQL, HTML5, CSS3, JavaScript, Git, Apache Tomcat");
        b.setSoftSkills("Teamwork, Communication, Problem Solving, Time Management");

        return b;
    }
}
