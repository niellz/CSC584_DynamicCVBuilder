# Dynamic Online CV Builder (CSC584) - Jakarta EE 10 / GlassFish 7

MVC web app: CVBean (Model), CVServlet (Controller), cvForm/cvView/cvError.jsp (View), web.xml.

## Requirements
- JDK 11 or newer (17 recommended), GlassFish 7 (Jakarta EE 10). JSTL is built into GlassFish.

## Run (NetBeans)
1. New Project -> Java with Maven -> Web Application, server GlassFish 7, Jakarta EE 10.
2. Copy src/main/java and src/main/webapp over the generated ones, and use the pom.xml dependency.
3. Clean and Build, then Run.
4. Form: http://localhost:8080/DynamicCVProject/   Sample: .../CVServlet?action=sample

## Run (WAR)
asadmin start-domain, then deploy DynamicCVProject.war at http://localhost:4848
